package uz.fokus.taymer

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlarmManager
import android.app.AlertDialog
import android.app.AppOpsManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.JsResult
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient

const val CHANNEL_ID = "fokus_alarm"

fun createChannel(ctx: Context) {
    val ch = NotificationChannel(CHANNEL_ID, "Taymer signali", NotificationManager.IMPORTANCE_HIGH)
    ch.enableVibration(true)
    ctx.getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
}

fun alarmIntent(ctx: Context, title: String, text: String): PendingIntent {
    val i = Intent(ctx, AlarmReceiver::class.java)
    i.putExtra("title", title)
    i.putExtra("text", text)
    return PendingIntent.getBroadcast(
        ctx, 1, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        createChannel(ctx)
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(intent.getStringExtra("title") ?: "Fokus Taymer")
            .setContentText(intent.getStringExtra("text") ?: "")
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify(1001, n)
    }
}

class MainActivity : Activity() {

    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannel(this)

        web = WebView(this)
        setContentView(web)

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false

        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onJsConfirm(
                view: WebView?, url: String?, message: String?, result: JsResult
            ): Boolean {
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setPositiveButton("OK") { _, _ -> result.confirm() }
                    .setNegativeButton("Bekor") { _, _ -> result.cancel() }
                    .setOnCancelListener { result.cancel() }
                    .show()
                return true
            }
        }
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onPause() {
        super.onPause()
        web.evaluateJavascript("window.__nativeHide&&window.__nativeHide()", null)
    }

    override fun onResume() {
        super.onResume()
        web.evaluateJavascript("window.__nativeShow&&window.__nativeShow()", null)
    }

    inner class Bridge {

        @JavascriptInterface
        fun schedule(endMillis: Double, title: String, text: String) {
            val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val show = PendingIntent.getActivity(
                this@MainActivity, 0, Intent(this@MainActivity, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            am.setAlarmClock(
                AlarmManager.AlarmClockInfo(endMillis.toLong(), show),
                alarmIntent(this@MainActivity, title, text)
            )
        }

        @JavascriptInterface
        fun cancel() {
            val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.cancel(alarmIntent(this@MainActivity, "", ""))
        }

        @JavascriptInterface
        fun keepScreenOn(on: Boolean) {
            runOnUiThread {
                if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }

        @JavascriptInterface
        fun hasUsageAccess(): Boolean {
            val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val mode = ops.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName
            )
            return mode == AppOpsManager.MODE_ALLOWED
        }

        @JavascriptInterface
        fun openUsageSettings() {
            runOnUiThread { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        }

        /** Boshqa ilovalarda o'tgan vaqt (soniya) va 5 soniyadan uzoq kirishlar soni, JSON ko'rinishida. */
        @JavascriptInterface
        fun otherAppsSeconds(fromMs: Double, toMs: Double): String {
            if (!hasUsageAccess()) return "{\"secs\":-1,\"n\":0}"
            val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val to = toMs.toLong()
            val ev = usm.queryEvents(fromMs.toLong(), to)
            val e = UsageEvents.Event()
            val started = HashMap<String, Long>()
            var total = 0L
            var n = 0

            fun close(st: Long, en: Long) {
                val d = en - st
                if (d > 0) {
                    total += d
                    if (d >= 5000) n++
                }
            }

            while (ev.hasNextEvent()) {
                ev.getNextEvent(e)
                val pkg: String = e.packageName ?: continue
                if (pkg == packageName) continue
                when (e.eventType) {
                    UsageEvents.Event.MOVE_TO_FOREGROUND -> started[pkg] = e.timeStamp
                    UsageEvents.Event.MOVE_TO_BACKGROUND -> {
                        val st = started.remove(pkg)
                        if (st != null) close(st, e.timeStamp)
                    }
                }
            }
            for (st in started.values) close(st, to)
            return "{\"secs\":${total / 1000},\"n\":$n}"
        }

        @JavascriptInterface
        fun shareText(text: String) {
            runOnUiThread {
                val i = Intent(Intent.ACTION_SEND)
                i.type = "text/plain"
                i.putExtra(Intent.EXTRA_TEXT, text)
                startActivity(Intent.createChooser(i, "Jurnalni yuborish"))
            }
        }
    }
}
